This converts the files from my proxy harvester into format IP:PORT so u can use them in your proxy lists more easily

For example this is a proxyfile from my harvester:
IP: 178.128.199.145, Port: 80, Type: HTTP, DNS: 178.128.199.145, Ping: 0.04s, Country: DE

after converting u get this:
178.128.199.145:80


Discord: https://discord.gg/zsGTqgnsmK
website: thezperformance.de